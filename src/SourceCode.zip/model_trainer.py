"""
Model Trainer for training machine learning models
"""

import numpy as np
import pandas as pd
import logging
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix, precision_score, recall_score, f1_score
from imblearn.over_sampling import SMOTE
from imblearn.combine import SMOTEENN
from imblearn.under_sampling import EditedNearestNeighbours
from collections import Counter
import joblib
import json
from datetime import datetime
from src.utils.file_manager import FileManager
from src.feature_extractor import FeatureExtractor
from src.model_compatibility import get_compatibility_manager

class ModelTrainer:
    """Trains machine learning models for misinformation detection."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.file_manager = FileManager()
        self.feature_extractor = FeatureExtractor()
        self.compatibility_manager = get_compatibility_manager()
        self.training_log_file = None
        self.training_logs = []
        
        # Default model configurations
        self.default_models = {
            'logistic_regression': LogisticRegression(random_state=42, max_iter=1000),
            'random_forest': RandomForestClassifier(random_state=42, n_estimators=100),
            'gradient_boosting': GradientBoostingClassifier(random_state=42, n_estimators=100),
            'svm': SVC(random_state=42, probability=True),
            'naive_bayes': GaussianNB(),
            'neural_network': MLPClassifier(random_state=42, max_iter=500)
        }
        
        # Specialized model configurations for theoretical frameworks
        # Each framework uses ALL 6 ML algorithms for comprehensive analysis
        self.specialized_models = {
            'ugt': {
                'logistic_regression': LogisticRegression(random_state=42, max_iter=1000),
                'random_forest': RandomForestClassifier(random_state=42, n_estimators=100),
                'gradient_boosting': GradientBoostingClassifier(random_state=42, n_estimators=100),
                'svm': SVC(random_state=42, probability=True),
                'naive_bayes': GaussianNB(),
                'neural_network': MLPClassifier(random_state=42, max_iter=500)
            },
            'rct': {
                'logistic_regression': LogisticRegression(random_state=42, max_iter=1000),
                'random_forest': RandomForestClassifier(random_state=42, n_estimators=100),
                'gradient_boosting': GradientBoostingClassifier(random_state=42, n_estimators=100),
                'svm': SVC(random_state=42, probability=True),
                'naive_bayes': GaussianNB(),
                'neural_network': MLPClassifier(random_state=42, max_iter=500)
            },
            'rat': {
                'logistic_regression': LogisticRegression(random_state=42, max_iter=1000),
                'random_forest': RandomForestClassifier(random_state=42, n_estimators=100),
                'gradient_boosting': GradientBoostingClassifier(random_state=42, n_estimators=100),
                'svm': SVC(random_state=42, probability=True),
                'naive_bayes': GaussianNB(),
                'neural_network': MLPClassifier(random_state=42, max_iter=500)
            },
            'combined': {
                # Combined model uses ensemble of best performers from each category
                'ensemble_voting': None,  # Will be created dynamically from best models
                'ensemble_stacking': None,  # Will be created dynamically
                'gradient_boosting_enhanced': GradientBoostingClassifier(random_state=42, n_estimators=200, learning_rate=0.1),
                'random_forest_enhanced': RandomForestClassifier(random_state=42, n_estimators=200, max_depth=10),
                'neural_network_enhanced': MLPClassifier(random_state=42, max_iter=1000, hidden_layer_sizes=(200, 100))
            }
        }
    
    def _init_training_logs(self, dataset_name):
        """Initialize training log file for a dataset."""
        try:
            # Create logs directory if it doesn't exist
            logs_dir = Path('logs')
            logs_dir.mkdir(exist_ok=True)
            
            # Create training log file
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            self.training_log_file = logs_dir / f'training_{dataset_name}_{timestamp}.log'
            
            # Clear previous logs
            self.training_logs = []
            
            # Write initial log entry
            self._write_training_log('info', f'Training session started for dataset: {dataset_name}')
            
        except Exception as e:
            self.logger.error(f"Error initializing training logs: {e}")
    
    def _write_training_log(self, level, message):
        """Write a log entry to both file and memory."""
        try:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            log_entry = {
                'timestamp': timestamp,
                'level': level,
                'message': message
            }
            
            # Add to memory (for real-time access)
            self.training_logs.append(log_entry)
            
            # Keep only last 100 log entries in memory
            if len(self.training_logs) > 100:
                self.training_logs = self.training_logs[-100:]
            
            # Write to file if available
            if self.training_log_file:
                with open(self.training_log_file, 'a', encoding='utf-8') as f:
                    f.write(f"[{timestamp}] {level.upper()}: {message}\n")
            
            # Also log to standard logger
            if level == 'info':
                self.logger.info(message)
            elif level == 'warning':
                self.logger.warning(message)
            elif level == 'error':
                self.logger.error(message)
                
        except Exception as e:
            self.logger.error(f"Error writing training log: {e}")
    
    def get_training_logs(self):
        """Get current training logs."""
        return self.training_logs.copy()
    
    def clear_training_logs(self):
        """Clear training logs from memory."""
        self.training_logs = []
    
    def _analyze_class_imbalance(self, y, dataset_name):
        """Analyze class distribution and determine if SMOTE is needed."""
        class_counts = Counter(y)
        total_samples = len(y)
        
        self._write_training_log('info', f"Class distribution analysis for {dataset_name}:")
        for class_label, count in sorted(class_counts.items()):
            percentage = (count / total_samples) * 100
            self._write_training_log('info', f"  Class {class_label}: {count} samples ({percentage:.1f}%)")
        
        # Calculate imbalance ratio (majority class / minority class)
        if len(class_counts) >= 2:
            max_count = max(class_counts.values())
            min_count = min(class_counts.values())
            imbalance_ratio = max_count / min_count
            
            self._write_training_log('info', f"Imbalance ratio: {imbalance_ratio:.2f}:1")
            
            # Recommend SMOTE if imbalance ratio > 2:1
            if imbalance_ratio > 2.0:
                self._write_training_log('info', f"⚠️  Class imbalance detected (ratio > 2:1). SMOTE recommended.")
                return True, imbalance_ratio
            else:
                self._write_training_log('info', f"✅ Classes are relatively balanced. SMOTE not required.")
                return False, imbalance_ratio
        
        return False, 1.0
    
    def _apply_smote(self, X_train, y_train, config):
        """Apply SMOTE or SMOTEENN based on configuration."""
        smote_strategy = config.get('smote_strategy', 'auto')  # 'auto', 'minority', 'not majority', or dict
        smote_method = config.get('smote_method', 'smote')  # 'smote' or 'smoteenn'
        smote_k_neighbors = config.get('smote_k_neighbors', 5)
        smote_random_state = config.get('smote_random_state', 42)
        
        self._write_training_log('info', f"Applying {smote_method.upper()} with strategy='{smote_strategy}', k_neighbors={smote_k_neighbors}")
        
        original_counts = Counter(y_train)
        self._write_training_log('info', f"Original training set: {dict(original_counts)}")
        
        try:
            if smote_method == 'smoteenn':
                # SMOTE + Edited Nearest Neighbours (combines oversampling and undersampling)
                smote_enn = SMOTEENN(
                    smote=SMOTE(
                        sampling_strategy=smote_strategy,
                        k_neighbors=smote_k_neighbors,
                        random_state=smote_random_state
                    ),
                    enn=EditedNearestNeighbours(
                        sampling_strategy='all',
                        n_neighbors=3
                    ),
                    random_state=smote_random_state
                )
                X_resampled, y_resampled = smote_enn.fit_resample(X_train, y_train)
            else:
                # Standard SMOTE
                smote = SMOTE(
                    sampling_strategy=smote_strategy,
                    k_neighbors=smote_k_neighbors,
                    random_state=smote_random_state
                )
                X_resampled, y_resampled = smote.fit_resample(X_train, y_train)
            
            resampled_counts = Counter(y_resampled)
            self._write_training_log('info', f"After {smote_method.upper()}: {dict(resampled_counts)}")
            
            # Calculate the change
            original_size = len(y_train)
            resampled_size = len(y_resampled)
            size_change = resampled_size - original_size
            
            self._write_training_log('info', f"Training set size: {original_size} → {resampled_size} ({size_change:+d} samples)")
            
            return X_resampled, y_resampled, True
            
        except Exception as e:
            self._write_training_log('warning', f"SMOTE failed: {str(e)}. Continuing with original data.")
            return X_train, y_train, False
    
    def train_models(self, dataset_name, selected_models):
        """Train selected models on the dataset."""
        # Initialize training logs
        self._init_training_logs(dataset_name)
        self._write_training_log('info', f"Starting training for models: {', '.join(selected_models)}")
        
        try:
            # Load configuration if exists
            self._write_training_log('info', "Loading model configuration...")
            config = self._load_model_config(dataset_name)
            
            # Load features
            self._write_training_log('info', "Loading features...")
            X, y, feature_names = self.feature_extractor.load_features(dataset_name)
            
            if X is None:
                self._write_training_log('error', "Features not found. Please extract features first.")
                raise ValueError("Features not found. Please extract features first.")
            
            # Split data using config parameters
            test_size = 1.0 - config.get('train_size', 0.8)
            self._write_training_log('info', f"Splitting data (train: {1-test_size:.1%}, test: {test_size:.1%})...")
            random_state = config.get('random_state', 42)
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size, random_state=random_state, stratify=y
            )
            
            # Scale features
            self._write_training_log('info', "Scaling features...")
            X_train_scaled, X_test_scaled = self.feature_extractor.scale_features(
                dataset_name, X_train, X_test
            )
            
            # Analyze class imbalance and apply SMOTE if needed
            self._write_training_log('info', "Analyzing class distribution...")
            needs_smote, imbalance_ratio = self._analyze_class_imbalance(y_train, dataset_name)
            
            # Apply SMOTE based on configuration
            use_smote = config.get('use_smote', 'auto')  # 'auto', True, False
            smote_applied = False
            
            if use_smote == 'auto':
                # Auto mode: apply SMOTE if imbalance detected
                if needs_smote:
                    X_train_scaled, y_train, smote_applied = self._apply_smote(X_train_scaled, y_train, config)
                else:
                    self._write_training_log('info', "SMOTE not needed - classes are balanced")
            elif use_smote is True:
                # Force SMOTE application
                self._write_training_log('info', "SMOTE forced by configuration")
                X_train_scaled, y_train, smote_applied = self._apply_smote(X_train_scaled, y_train, config)
            else:
                # SMOTE disabled
                self._write_training_log('info', "SMOTE disabled by configuration")
            
            self._write_training_log('info', f"Data prepared: {len(X_train_scaled)} training samples, {len(X_test)} test samples, {X.shape[1]} features")
            
            training_results = {
                'dataset_name': dataset_name,
                'training_date': datetime.now().isoformat(),
                'data_split': {
                    'train_samples': len(X_train_scaled),
                    'test_samples': len(X_test),
                    'total_features': X.shape[1],
                    'original_train_samples': len(X_train),
                    'smote_applied': smote_applied,
                    'imbalance_ratio': imbalance_ratio
                },
                'models': {}
            }
            
            # Train each selected model
            self._write_training_log('info', f"Starting training for {len(selected_models)} models...")
            for i, model_name in enumerate(selected_models, 1):
                if model_name == 'zero_shot':
                    # Handle zero-shot classification separately
                    self._write_training_log('info', f"[{i}/{len(selected_models)}] Running zero-shot classification...")
                    zero_shot_results = self._run_zero_shot_classification(dataset_name, config)
                    training_results['models']['zero_shot'] = zero_shot_results
                    self._write_training_log('info', f"Zero-shot classification completed")
                    continue
                    
                if model_name not in self.default_models:
                    self._write_training_log('warning', f"Unknown model: {model_name}")
                    continue
                
                self._write_training_log('info', f"[{i}/{len(selected_models)}] Training {model_name}...")
                
                try:
                    # Train model with config parameters
                    model = self._get_configured_model(model_name, config)
                    self._write_training_log('info', f"Fitting {model_name} model...")
                    model.fit(X_train_scaled, y_train)
                    
                    # Evaluate model
                    self._write_training_log('info', f"Evaluating {model_name} model...")
                    train_score = model.score(X_train_scaled, y_train)
                    test_score = model.score(X_test_scaled, y_test)
                    
                    # Cross-validation using config parameters
                    cv_folds = config.get('cv_folds', 5)
                    scoring_metric = config.get('scoring_metric', 'f1')
                    self._write_training_log('info', f"Running {cv_folds}-fold cross-validation for {model_name}...")
                    cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=cv_folds, scoring=scoring_metric)
                    
                    # Predictions for detailed metrics
                    y_pred = model.predict(X_test_scaled)
                    
                    # Calculate additional metrics
                    self._write_training_log('info', f"Calculating detailed metrics for {model_name}...")
                    precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
                    recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
                    f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
                    
                    # Store comprehensive results
                    training_results['models'][model_name] = {
                        'train_accuracy': float(train_score),
                        'test_accuracy': float(test_score),
                        'precision': float(precision),
                        'recall': float(recall),
                        'f1_score': float(f1),
                        'cv_f1_mean': float(cv_scores.mean()),
                        'cv_f1_std': float(cv_scores.std()),
                        'classification_report': classification_report(y_test, y_pred, output_dict=True),
                        'confusion_matrix': confusion_matrix(y_test, y_pred).tolist(),
                        'feature_count': X_train_scaled.shape[1],
                        'model_type': model_name
                    }
                    
                    # Save complete model with preprocessing pipeline
                    self._write_training_log('info', f"Saving {model_name} model...")
                    model_path = self.file_manager.get_model_path(dataset_name, model_name)
                    
                    # Get the scaler used for this dataset
                    scaler = self.feature_extractor.get_scaler(dataset_name)
                    
                    # Create complete model package with enhanced metadata
                    complete_model = {
                        'model': model,
                        'scaler': scaler,
                        'feature_columns': self.feature_extractor.get_feature_names(dataset_name),
                        'label_encoder': getattr(self.feature_extractor, 'label_encoder', None),
                        'model_metadata': {
                            'model_name': model_name,
                            'dataset_name': dataset_name,
                            'training_date': datetime.now().isoformat(),
                            'metrics': training_results['models'][model_name],
                            'feature_types': self.feature_extractor.get_feature_types(dataset_name),
                            'expected_features': X_train_scaled.shape[1],
                            'sklearn_version': getattr(model, '_sklearn_version', 'unknown'),
                            'python_version': f"{__import__('sys').version_info.major}.{__import__('sys').version_info.minor}",
                            'numpy_version': np.__version__,
                            'compatibility_version': '1.0'
                        }
                    }
                    
                    # Save complete model with compatibility enhancement
                    self._write_training_log('info', f"Saving {model_name} with compatibility enhancements...")
                    try:
                        # Use standard joblib save but with enhanced error handling
                        joblib.dump(complete_model, model_path)
                        
                        # Validate the saved model can be loaded
                        test_load = self.compatibility_manager.safe_load_model(model_path)
                        if test_load is None:
                            raise RuntimeError("Model validation failed after saving")
                        
                        self._write_training_log('info', f"✅ Model {model_name} saved and validated successfully")
                        
                    except Exception as save_error:
                        self._write_training_log('warning', f"Standard save failed, trying compatibility save: {save_error}")
                        # Fallback: save model components separately
                        self._save_model_with_fallback(model_path, complete_model, model_name)
                    
                    # Also save individual model metrics for easy access
                    metrics_path = model_path.replace('.joblib', '_metrics.json')
                    with open(metrics_path, 'w') as f:
                        json.dump(training_results['models'][model_name], f, indent=2)
                    
                    self._write_training_log('info', f"✅ {model_name} training completed! Test accuracy: {test_score:.4f}, F1: {f1:.4f}")
                    
                except Exception as e:
                    self._write_training_log('error', f"❌ Error training {model_name}: {str(e)}")
                    # Store error info but continue with other models
                    training_results['models'][model_name] = {
                        'error': str(e),
                        'model_type': model_name,
                        'test_accuracy': 0.0,
                        'precision': 0.0,
                        'recall': 0.0,
                        'f1_score': 0.0,
                        'status': 'failed'
                    }
            
            # Find and mark best performing model
            self._write_training_log('info', "Determining best performing model...")
            best_model_name, best_score = self._find_best_model(training_results['models'])
            if best_model_name:
                training_results['best_model'] = {
                    'name': best_model_name,
                    'f1_score': best_score,
                    'path': str(self.file_manager.get_model_path(dataset_name, best_model_name))
                }
                self._write_training_log('info', f"🏆 Best performing model: {best_model_name} (F1: {best_score:.4f})")
            
            # Save training results
            self._write_training_log('info', "Saving training results...")
            self.file_manager.save_results(dataset_name, training_results, 'model_training')
            
            # Update dataset info
            self.file_manager.update_dataset_info(dataset_name, {
                'status': 'models_trained',
                'models_trained': list(selected_models),
                'best_model': best_model_name,
                'best_f1_score': best_score
            })
            
            self._write_training_log('info', "🎉 All model training completed successfully!")
            return training_results
            
        except Exception as e:
            self._write_training_log('error', f"💥 Critical error during model training: {str(e)}")
            raise
    
    def _find_best_model(self, models_results):
        """Find the best performing model based on F1 score."""
        best_name = None
        best_score = 0.0
        
        for model_name, results in models_results.items():
            if 'error' in results:
                continue
            f1_score = results.get('f1_score', 0.0)
            if f1_score > best_score:
                best_score = f1_score
                best_name = model_name
        
        return best_name, best_score
    
    def _run_zero_shot_classification(self, dataset_name: str, config: dict) -> dict:
        """Run zero-shot classification as part of model training pipeline."""
        self.logger.info("Running zero-shot classification in training pipeline")
        
        try:
            # Get zero-shot configuration
            zero_shot_config = config.get('zero_shot_config', {
                'model': 'facebook/bart-large-mnli',
                'confidence_threshold': 0.7,
                'label_set': 'binary',
                'kenyan_context': True,
                'multilingual': True
            })
            
            # Import zero-shot classifier
            from .zero_shot_labeling import ZeroShotLabeler
            zero_shot_classifier = ZeroShotLabeler(self.file_manager)
            
            # Run zero-shot classification
            zero_shot_results = zero_shot_classifier.classify_dataset(dataset_name, zero_shot_config)
            
            # Save zero-shot results
            self.save_zero_shot_model(dataset_name, zero_shot_results)
            
            # Format results for training pipeline
            formatted_results = {
                'model_name': 'zero_shot',
                'model_type': 'transformer',
                'training_time': zero_shot_results.get('processing_time', 'N/A'),
                'accuracy': zero_shot_results.get('average_confidence', 0.0),
                'f1_score': zero_shot_results.get('average_confidence', 0.0),  # Use confidence as proxy
                'precision': zero_shot_results.get('average_confidence', 0.0),
                'recall': zero_shot_results.get('average_confidence', 0.0),
                'total_classified': zero_shot_results.get('total_classified', 0),
                'misinformation_detected': zero_shot_results.get('misinformation_detected', 0),
                'model_config': zero_shot_config,
                'notes': 'Zero-shot classification using pre-trained transformer'
            }
            
            return formatted_results
            
        except Exception as e:
            self.logger.error(f"Error in zero-shot classification: {e}")
            return {
                'model_name': 'zero_shot',
                'error': str(e),
                'status': 'failed'
            }
    
    def save_zero_shot_model(self, dataset_name: str, zero_shot_results: dict):
        """Save zero-shot model results for later use."""
        try:
            # Create zero-shot model package
            zero_shot_model = {
                'model_type': 'zero_shot',
                'model_name': zero_shot_results.get('model_name', 'facebook/bart-large-mnli'),
                'results': zero_shot_results,
                'training_date': datetime.now().isoformat(),
                'dataset_name': dataset_name,
                'live_prediction_capable': True
            }
            
            # Save zero-shot model
            zs_model_path = self.file_manager.get_model_path(dataset_name, 'zero_shot')
            joblib.dump(zero_shot_model, zs_model_path)
            
            # Save metrics separately
            zs_metrics_path = zs_model_path.replace('.joblib', '_metrics.json')
            with open(zs_metrics_path, 'w') as f:
                json.dump(zero_shot_results, f, indent=2)
            
            self.logger.info(f"Zero-shot model saved for {dataset_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error saving zero-shot model: {e}")
            return False
            return training_results
            
        except Exception as e:
            self.logger.error(f"Error in model training: {e}")
            raise
    
    def get_training_results(self, dataset_name):
        """Get the latest training results for a dataset."""
        return self.file_manager.load_results(dataset_name, 'model_training')
    
    def retrain_model(self, dataset_name, model_name, custom_params=None):
        """Retrain a specific model with custom parameters."""
        self.logger.info(f"Retraining {model_name} for dataset: {dataset_name}")
        
        try:
            # Load features
            X, y, feature_names = self.feature_extractor.load_features(dataset_name)
            
            if X is None:
                raise ValueError("Features not found. Please extract features first.")
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42, stratify=y
            )
            
            # Scale features
            X_train_scaled, X_test_scaled = self.feature_extractor.scale_features(
                dataset_name, X_train, X_test
            )
            
            # Get model with custom parameters
            if custom_params:
                model = self._get_model_with_params(model_name, custom_params)
            else:
                model = self.default_models[model_name]
            
            # Train model
            model.fit(X_train_scaled, y_train)
            
            # Evaluate
            test_score = model.score(X_test_scaled, y_test)
            
            # Save retrained model
            model_path = self.file_manager.get_model_path(dataset_name, f"{model_name}_retrained")
            joblib.dump(model, model_path)
            
            self.logger.info(f"Retraining completed. Test accuracy: {test_score:.4f}")
            
            return {
                'model_name': model_name,
                'test_accuracy': float(test_score),
                'custom_params': custom_params,
                'retrain_date': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error retraining model: {e}")
            raise
    
    def _get_model_with_params(self, model_name, params):
        """Get model instance with custom parameters."""
        if model_name == 'logistic_regression':
            return LogisticRegression(random_state=42, **params)
        elif model_name == 'random_forest':
            return RandomForestClassifier(random_state=42, **params)
        elif model_name == 'gradient_boosting':
            return GradientBoostingClassifier(random_state=42, **params)
        elif model_name == 'svm':
            return SVC(random_state=42, probability=True, **params)
        elif model_name == 'naive_bayes':
            return GaussianNB(**params)
        elif model_name == 'neural_network':
            return MLPClassifier(random_state=42, **params)
        else:
            raise ValueError(f"Unknown model: {model_name}")
    
    def compare_models(self, dataset_name):
        """Compare performance of all trained models."""
        training_results = self.get_training_results(dataset_name)
        
        if not training_results or 'models' not in training_results:
            return None
        
        comparison = {
            'dataset_name': dataset_name,
            'comparison_date': datetime.now().isoformat(),
            'models': []
        }
        
        for model_name, results in training_results['models'].items():
            if 'error' not in results:
                comparison['models'].append({
                    'name': model_name,
                    'test_accuracy': results['test_accuracy'],
                    'cv_f1_mean': results['cv_f1_mean'],
                    'cv_f1_std': results['cv_f1_std']
                })
        
        # Sort by test accuracy
        comparison['models'].sort(key=lambda x: x['test_accuracy'], reverse=True)
        
        return comparison
    
    def _load_model_config(self, dataset_name):
        """Load model configuration from saved config file."""
        import json
        from pathlib import Path
        
        # Try gratification config first, then traditional config
        config_paths = [
            Path('datasets') / dataset_name / 'config' / 'gratification_model_config.json',
            Path('datasets') / dataset_name / 'config' / 'model_config.json'
        ]
        
        for config_path in config_paths:
            if config_path.exists():
                try:
                    with open(config_path, 'r') as f:
                        config = json.load(f)
                    self.logger.info(f"Loaded model config from {config_path}")
                    return config
                except Exception as e:
                    self.logger.warning(f"Error loading config from {config_path}: {e}")
        
        # Return default config if no config file found
        self.logger.info("Using default model configuration")
        return {
            'train_size': 0.8,
            'random_state': 42,
            'cv_folds': 5,
            'scoring_metric': 'f1',
            # SMOTE configuration
            'use_smote': 'auto',  # 'auto', True, False
            'smote_method': 'smote',  # 'smote' or 'smoteenn'
            'smote_strategy': 'auto',  # 'auto', 'minority', 'not majority', or dict
            'smote_k_neighbors': 5,
            'smote_random_state': 42
        }
    
    def _get_configured_model(self, model_name, config):
        """Get model instance with configuration parameters applied."""
        random_state = config.get('random_state', 42)
        
        if model_name == 'logistic_regression':
            return LogisticRegression(
                C=config.get('lr_C', 1.0),
                solver=config.get('lr_solver', 'liblinear'),
                max_iter=config.get('lr_max_iter', 1000),
                random_state=random_state
            )
        elif model_name == 'random_forest':
            max_depth = config.get('rf_max_depth', 'None')
            max_depth = None if max_depth == 'None' else int(max_depth)
            return RandomForestClassifier(
                n_estimators=config.get('rf_n_estimators', 100),
                max_depth=max_depth,
                min_samples_split=config.get('rf_min_samples_split', 2),
                random_state=random_state
            )
        elif model_name == 'gradient_boosting':
            return GradientBoostingClassifier(
                n_estimators=config.get('gb_n_estimators', 100),
                learning_rate=config.get('gb_learning_rate', 0.1),
                max_depth=config.get('gb_max_depth', 3),
                random_state=random_state
            )
        elif model_name == 'svm':
            return SVC(
                C=config.get('svm_C', 1.0),
                kernel=config.get('svm_kernel', 'rbf'),
                probability=True,
                random_state=random_state
            )
        elif model_name == 'naive_bayes':
            return GaussianNB()
        elif model_name == 'neural_network':
            return MLPClassifier(
                hidden_layer_sizes=tuple(config.get('nn_hidden_layers', [100])),
                learning_rate_init=config.get('nn_learning_rate', 0.001),
                max_iter=config.get('nn_max_iter', 500),
                random_state=random_state
            )
        else:
            # Fallback to default models
            return self.default_models.get(model_name)
    
    def _save_model_with_fallback(self, model_path, complete_model, model_name):
        """Fallback method to save model with compatibility issues."""
        try:
            # Try saving components separately
            model_dir = Path(model_path).parent
            model_stem = Path(model_path).stem
            
            # Save individual components
            model_only_path = model_dir / f"{model_stem}_model_only.joblib"
            scaler_path = model_dir / f"{model_stem}_scaler.joblib"
            metadata_path = model_dir / f"{model_stem}_metadata.json"
            
            # Save core model
            joblib.dump(complete_model['model'], model_only_path)
            
            # Save scaler if exists
            if complete_model['scaler']:
                joblib.dump(complete_model['scaler'], scaler_path)
            
            # Save metadata
            with open(metadata_path, 'w') as f:
                json.dump(complete_model['model_metadata'], f, indent=2)
            
            # Create a compatibility wrapper
            fallback_model = {
                'model_path': str(model_only_path),
                'scaler_path': str(scaler_path) if complete_model['scaler'] else None,
                'metadata_path': str(metadata_path),
                'feature_columns': complete_model['feature_columns'],
                'label_encoder': complete_model['label_encoder'],
                'model_metadata': complete_model['model_metadata'],
                'fallback_save': True
            }
            
            # Save the wrapper
            joblib.dump(fallback_model, model_path)
            self._write_training_log('info', f"✅ Model {model_name} saved using fallback method")
            
        except Exception as e:
            self._write_training_log('error', f"❌ Fallback save also failed for {model_name}: {e}")
            raise
    
    def train_specialized_models(self, dataset_name, model_types=None, feature_config=None):
        """
        Train specialized models for different theoretical frameworks.
        Integrates with existing transformer-based pipeline.
        
        Args:
            dataset_name: Name of the dataset
            model_types: List of model types ['ugt', 'rct', 'rat', 'traditional_ml', 'combined']
            feature_config: Configuration for feature extraction
        """
        if model_types is None:
            model_types = ['ugt', 'rct', 'rat', 'traditional_ml', 'combined']
        
        self._init_training_logs(dataset_name)
        self._write_training_log('info', f"Starting specialized model training for: {', '.join(model_types)}")
        
        if feature_config is None:
            feature_config = {
                'use_embeddings': True,  # Use your existing transformer embeddings
                'use_enhanced_text': True,  # Use new enhanced text features
                'embedding_config': {
                    'embedding_model': 'sentence-transformers/all-MiniLM-L6-v2',
                    'embedding_strategy': 'mean_pooling'
                }
            }
        
        results = {
            'dataset_name': dataset_name,
            'training_date': datetime.now().isoformat(),
            'model_types': {},
            'feature_config': feature_config
        }
        
        try:
            # Extract comprehensive features (includes transformers + enhanced text)
            self._write_training_log('info', "Extracting comprehensive features...")
            feature_info = self.feature_extractor.extract_comprehensive_features(
                dataset_name,
                embedding_config=feature_config.get('embedding_config') if feature_config.get('use_embeddings') else None,
                zero_shot_config={'run_zero_shot': False}  # Can be enabled if needed
            )
            
            # Load features
            X, y, feature_names = self.feature_extractor.load_features(dataset_name)
            
            if X is None:
                raise ValueError("Features not found. Please extract features first.")
            
            self._write_training_log('info', f"Loaded features: {X.shape[1]} features, {len(X)} samples")
            
            # Train each model type
            for model_type in model_types:
                self._write_training_log('info', f"Training {model_type.upper()} models...")
                try:
                    if model_type in ['ugt', 'rct', 'rat']:
                        model_results = self._train_theoretical_framework_models(
                            X, y, feature_names, dataset_name, model_type
                        )
                    elif model_type == 'traditional_ml':
                        model_results = self._train_traditional_models_specialized(
                            X, y, feature_names, dataset_name
                        )
                    elif model_type == 'combined':
                        model_results = self._train_combined_models_specialized(
                            X, y, feature_names, dataset_name
                        )
                    else:
                        self._write_training_log('warning', f"Unknown model type: {model_type}")
                        continue
                    
                    results['model_types'][model_type] = model_results
                    self._write_training_log('info', f"Successfully trained {model_type.upper()} models")
                    
                except Exception as e:
                    self._write_training_log('error', f"Error training {model_type} models: {e}")
                    results['model_types'][model_type] = {'error': str(e)}
            
            # Save overall results
            self._save_specialized_training_results(dataset_name, results)
            
            return results
            
        except Exception as e:
            self._write_training_log('error', f"Error in specialized training: {e}")
            raise
    
    def _train_theoretical_framework_models(self, X, y, feature_names, dataset_name, framework_type):
        """Train models for a specific theoretical framework (UGT, RCT, RAT)."""
        from sklearn.model_selection import train_test_split, cross_val_score
        from sklearn.preprocessing import StandardScaler
        from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Scale features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        models = self.specialized_models[framework_type]
        results = {
            'framework_type': framework_type,
            'feature_count': X.shape[1],
            'train_samples': len(X_train),
            'test_samples': len(X_test),
            'models': {}
        }
        
        for model_name, model in models.items():
            try:
                self._write_training_log('info', f"Training {framework_type} {model_name}...")
                
                # Train model
                model.fit(X_train_scaled, y_train)
                
                # Evaluate
                train_score = model.score(X_train_scaled, y_train)
                test_score = model.score(X_test_scaled, y_test)
                
                # Cross-validation
                cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=5)
                
                # Detailed metrics
                y_pred = model.predict(X_test_scaled)
                y_pred_proba = model.predict_proba(X_test_scaled)[:, 1] if hasattr(model, 'predict_proba') else None
                
                model_results = {
                    'train_accuracy': train_score,
                    'test_accuracy': test_score,
                    'cv_mean': cv_scores.mean(),
                    'cv_std': cv_scores.std(),
                    'classification_report': classification_report(y_test, y_pred, output_dict=True),
                    'confusion_matrix': confusion_matrix(y_test, y_pred).tolist(),
                    'roc_auc': roc_auc_score(y_test, y_pred_proba) if y_pred_proba is not None else None
                }
                
                results['models'][model_name] = model_results
                
                # Save model
                self._save_specialized_model(dataset_name, framework_type, model_name, model, scaler, feature_names, model_results)
                
                self._write_training_log('info', f"{framework_type} {model_name}: Test Acc={test_score:.3f}, CV={cv_scores.mean():.3f}")
                
            except Exception as e:
                self._write_training_log('error', f"Error training {framework_type} {model_name}: {e}")
                results['models'][model_name] = {'error': str(e)}
        
        return results
    
    def _train_traditional_models_specialized(self, X, y, feature_names, dataset_name):
        """Train traditional ML models with specialized saving."""
        # Use existing train_models method but with specialized saving
        selected_models = list(self.default_models.keys())
        
        # Temporarily redirect to specialized saving
        original_method = self.train_models
        
        try:
            # Train using existing method
            training_results = original_method(dataset_name, selected_models)
            
            # Reformat results for consistency
            results = {
                'framework_type': 'traditional_ml',
                'feature_count': X.shape[1],
                'models': {}
            }
            
            for model_name, model_data in training_results.get('models', {}).items():
                if 'error' not in model_data:
                    results['models'][model_name] = {
                        'train_accuracy': model_data.get('train_accuracy', 0),
                        'test_accuracy': model_data.get('test_accuracy', 0),
                        'cv_mean': model_data.get('cv_mean', 0),
                        'cv_std': model_data.get('cv_std', 0),
                        'roc_auc': model_data.get('roc_auc', 0)
                    }
                else:
                    results['models'][model_name] = model_data
            
            return results
            
        except Exception as e:
            self._write_training_log('error', f"Error in traditional ML training: {e}")
            return {'error': str(e)}
    
    def _train_combined_models_specialized(self, X, y, feature_names, dataset_name):
        """
        Train combined/ensemble models using best performers from each category:
        - Best Traditional ML models (all 6 algorithms)
        - Best Framework models (UGT, RCT, RAT)
        - Transformer embeddings integration
        """
        from sklearn.model_selection import train_test_split, cross_val_score
        from sklearn.preprocessing import StandardScaler
        from sklearn.ensemble import VotingClassifier, StackingClassifier
        from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
        
        self._write_training_log('info', "Training COMBINED models with ALL 6 ML algorithms + Transformers")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Scale features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        results = {
            'framework_type': 'combined',
            'feature_count': X.shape[1],
            'train_samples': len(X_train),
            'test_samples': len(X_test),
            'models': {},
            'feature_breakdown': {
                'total_features': X.shape[1],
                'bert_embeddings': '768 dims (estimated)',
                'sentence_transformers': '384 dims (estimated)', 
                'theoretical_frameworks': '45 dims (UGT+RCT+RAT)',
                'behavioral_analysis': '44 dims',
                'traditional_features': f'{X.shape[1] - 1241} dims (TF-IDF, sentiment, etc.)'
            }
        }
        
        # Train ALL 6 traditional ML models for ensemble selection
        self._write_training_log('info', "Training all 6 traditional ML algorithms...")
        base_models = []
        model_performances = {}
        
        for name, model in self.default_models.items():
            try:
                self._write_training_log('info', f"Training {name} for ensemble...")
                model_copy = model.__class__(**model.get_params())
                model_copy.fit(X_train_scaled, y_train)
                
                # Evaluate performance
                test_score = model_copy.score(X_test_scaled, y_test)
                cv_scores = cross_val_score(model_copy, X_train_scaled, y_train, cv=3)
                
                model_performances[name] = {
                    'test_accuracy': test_score,
                    'cv_mean': cv_scores.mean(),
                    'model': model_copy
                }
                
                # Add to base models if performance is good
                if test_score > 0.6:  # Only include decent performers
                    base_models.append((name, model_copy))
                    self._write_training_log('info', f"{name}: Test Acc={test_score:.3f}, CV={cv_scores.mean():.3f} ✅")
                else:
                    self._write_training_log('warning', f"{name}: Test Acc={test_score:.3f} - excluded from ensemble")
                    
            except Exception as e:
                self._write_training_log('error', f"Could not train {name} for ensemble: {e}")
        
        # Create ensemble voting classifier with best models
        if len(base_models) >= 3:
            self._write_training_log('info', f"Creating ensemble with {len(base_models)} models")
            ensemble_voting = VotingClassifier(estimators=base_models, voting='soft')
            self.specialized_models['combined']['ensemble_voting'] = ensemble_voting
            
            # Create stacking classifier with best models
            if len(base_models) >= 4:
                # Use best performer as meta-learner
                best_model_name = max(model_performances.keys(), 
                                    key=lambda x: model_performances[x]['test_accuracy'])
                meta_learner = model_performances[best_model_name]['model']
                
                ensemble_stacking = StackingClassifier(
                    estimators=base_models[:4],  # Use top 4 as base learners
                    final_estimator=meta_learner,
                    cv=3
                )
                self.specialized_models['combined']['ensemble_stacking'] = ensemble_stacking
                self._write_training_log('info', f"Created stacking ensemble with {best_model_name} as meta-learner")
        
        # Train all combined models
        models = self.specialized_models['combined']
        for model_name, model in models.items():
            if model is None:
                continue
                
            try:
                self._write_training_log('info', f"Training combined {model_name}...")
                
                # Train model
                model.fit(X_train_scaled, y_train)
                
                # Evaluate
                train_score = model.score(X_train_scaled, y_train)
                test_score = model.score(X_test_scaled, y_test)
                
                # Cross-validation (reduced for complex models)
                cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=3)
                
                # Detailed metrics
                y_pred = model.predict(X_test_scaled)
                y_pred_proba = model.predict_proba(X_test_scaled)[:, 1] if hasattr(model, 'predict_proba') else None
                
                model_results = {
                    'train_accuracy': train_score,
                    'test_accuracy': test_score,
                    'cv_mean': cv_scores.mean(),
                    'cv_std': cv_scores.std(),
                    'classification_report': classification_report(y_test, y_pred, output_dict=True),
                    'confusion_matrix': confusion_matrix(y_test, y_pred).tolist(),
                    'roc_auc': roc_auc_score(y_test, y_pred_proba) if y_pred_proba is not None else None
                }
                
                results['models'][model_name] = model_results
                
                # Save model
                self._save_specialized_model(dataset_name, 'combined', model_name, model, scaler, feature_names, model_results)
                
                self._write_training_log('info', f"Combined {model_name}: Test Acc={test_score:.3f}, CV={cv_scores.mean():.3f}")
                
            except Exception as e:
                self._write_training_log('error', f"Error training combined {model_name}: {e}")
                results['models'][model_name] = {'error': str(e)}
        
        return results
    
    def _save_specialized_model(self, dataset_name, model_type, model_name, model, scaler, feature_names, metrics):
        """Save specialized model with organized directory structure."""
        try:
            # Create directory structure
            model_dir = Path('models') / dataset_name / model_type
            model_dir.mkdir(parents=True, exist_ok=True)
            
            model_path = model_dir / f'{model_name}.joblib'
            
            # Create complete model package
            complete_model = {
                'model': model,
                'scaler': scaler,
                'feature_names': feature_names,
                'model_type': model_type,
                'model_name': model_name,
                'training_date': datetime.now().isoformat(),
                'metrics': metrics,
                'feature_count': len(feature_names)
            }
            
            joblib.dump(complete_model, model_path)
            
            # Save metadata
            metadata = {
                'model_type': model_type,
                'model_name': model_name,
                'feature_count': len(feature_names),
                'training_date': datetime.now().isoformat(),
                'metrics': {k: v for k, v in metrics.items() if k not in ['classification_report', 'confusion_matrix']}
            }
            
            metadata_path = model_dir / 'metadata.json'
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2, default=str)
            
            self._write_training_log('info', f"Saved {model_type} {model_name} model")
            
        except Exception as e:
            self._write_training_log('error', f"Error saving {model_type} {model_name}: {e}")
    
    def _save_specialized_training_results(self, dataset_name, results):
        """Save overall specialized training results."""
        try:
            results_dir = Path('models') / dataset_name
            results_dir.mkdir(parents=True, exist_ok=True)
            
            results_path = results_dir / 'specialized_training_results.json'
            with open(results_path, 'w') as f:
                json.dump(results, f, indent=2, default=str)
            
            self._write_training_log('info', f"Saved specialized training results")
            
        except Exception as e:
            self._write_training_log('error', f"Error saving training results: {e}")
    
    def load_specialized_model(self, dataset_name, model_type, model_name):
        """Load a specific specialized model."""
        try:
            model_path = Path('models') / dataset_name / model_type / f'{model_name}.joblib'
            
            if model_path.exists():
                complete_model = joblib.load(model_path)
                self.logger.info(f"Loaded {model_type} {model_name} model")
                return complete_model
            else:
                self.logger.warning(f"Model not found: {model_path}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error loading specialized model: {e}")
            return None
    
    def get_specialized_model_comparison(self, dataset_name):
        """Get comparison of all specialized trained models."""
        try:
            results_path = Path('models') / dataset_name / 'specialized_training_results.json'
            
            if results_path.exists():
                with open(results_path, 'r') as f:
                    results = json.load(f)
                
                # Extract key metrics for comparison
                comparison = {}
                
                for model_type, type_results in results.get('model_types', {}).items():
                    if 'models' in type_results:
                        comparison[model_type] = {}
                        for model_name, model_results in type_results['models'].items():
                            if 'error' not in model_results:
                                comparison[model_type][model_name] = {
                                    'test_accuracy': model_results.get('test_accuracy', 0),
                                    'cv_mean': model_results.get('cv_mean', 0),
                                    'roc_auc': model_results.get('roc_auc', 0)
                                }
                
                return comparison
            else:
                return {}
                
        except Exception as e:
            self.logger.error(f"Error getting specialized model comparison: {e}")
            return {}